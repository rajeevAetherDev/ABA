/**
 * urbanpiper_store_connector — Store-side pull agent
 *
 * Purpose: Polls the CLOUD TGIF server for pending UrbanPiper jobs and
 *          dispatches them to the LOCAL TGIF POS server. Then acks back
 *          to cloud with success/failure.
 *
 * Architecture:
 *   - No inbound networking required at store (store has dynamic IP)
 *   - Polls CLOUD /urbanpiper/store/pull_jobs every POLL_INTERVAL ms
 *   - For each job calls LOCAL /local_up/order_create|update|cancel
 *   - Then calls CLOUD /urbanpiper/store/ack_job
 *
 * Usage:
 *   cp .env.example .env   # fill in values
 *   node connector.js
 *
 * Requires Node.js >= 14
 *
 * @author  Aether Integration Engineering
 * @version 1.0  2026-03-03
 */

'use strict';

const https  = require('https');
const http   = require('http');
const fs     = require('fs');
const path   = require('path');
const net    = require('net');

// ---------------------------------------------------------------------------
// Config (from .env file or environment variables)
// ---------------------------------------------------------------------------

function loadEnv() {
  const envFile = path.join(__dirname, '.env');
  if (fs.existsSync(envFile)) {
    const lines = fs.readFileSync(envFile, 'utf8').split('\n');
    for (const line of lines) {
      const trimmed = line.trim();
      if (!trimmed || trimmed.startsWith('#')) continue;
      const eq = trimmed.indexOf('=');
      if (eq > 0) {
        const key = trimmed.slice(0, eq).trim();
        const val = trimmed.slice(eq + 1).trim().replace(/^["']|["']$/g, '');
        if (!process.env[key]) process.env[key] = val;
      }
    }
  }
}

loadEnv();

const CONFIG = {
  CLOUD_BASE_URL  : process.env.CLOUD_BASE_URL   || 'http://phylopos.in/TGI/erp',
  STORE_KEY       : process.env.STORE_KEY         || 'TGIF_STORE_01',
  STORE_TOKEN     : process.env.STORE_TOKEN       || '37c20566b55517389653a1d99e48552d8003e3498b9a25f4b3127b1277360dc1',
  LOCAL_BASE_URL  : process.env.LOCAL_BASE_URL    || 'http://192.168.1.250:8080/erp',
  POLL_INTERVAL   : parseInt(process.env.POLL_INTERVAL || '2000', 10),
  LOG_FILE        : process.env.LOG_FILE          || path.join(__dirname, 'connector.log'),
};

if (!CONFIG.STORE_KEY || !CONFIG.STORE_TOKEN) {
  console.error('[FATAL] STORE_KEY and STORE_TOKEN must be set in .env');
  process.exit(1);
}

// ---------------------------------------------------------------------------
// Logging
// ---------------------------------------------------------------------------

function log(level, msg) {
  const line = `[${new Date().toISOString()}] ${level.padEnd(5)} ${msg}`;
  console.log(line);
  try {
    fs.appendFileSync(CONFIG.LOG_FILE, line + '\n');
  } catch (e) { /* non-fatal */ }
}

const logger = {
  info : (m) => log('INFO',  m),
  warn : (m) => log('WARN',  m),
  error: (m) => log('ERROR', m),
};


// ---------------------------------------------------------------------------
// Network connectivity checker
// ---------------------------------------------------------------------------

function checkSocket(host, port, timeoutMs) {
  return new Promise((resolve) => {
    const socket = new net.Socket();
    socket.setTimeout(timeoutMs);
    socket.once('connect', () => {
      socket.destroy();
      resolve(true);
    });
    socket.once('timeout', () => {
      socket.destroy();
      resolve(false);
    });
    socket.once('error', () => {
      socket.destroy();
      resolve(false);
    });
    socket.connect(port, host);
  });
}

/**
 * Pre-flight internet & cloud connection check.
 * Uses low-level socket connections in parallel to verify internet without DNS dependency.
 */
async function checkInternetConnection(timeoutMs = 2500) {
  const checks = await Promise.all([
    checkSocket('8.8.8.8', 53, timeoutMs),
    checkSocket('103.35.121.89', 80, timeoutMs),
  ]);
  return checks.includes(true);
}



// ---------------------------------------------------------------------------
// HTTP helpers
// ---------------------------------------------------------------------------

function request(url, options = {}) {
  return new Promise((resolve, reject) => {
    const parsed = new URL(url);
    const lib    = parsed.protocol === 'https:' ? https : http;
    const reqOptions = {
      hostname: parsed.hostname,
      port    : parsed.port || (parsed.protocol === 'https:' ? 443 : 80),
      path    : parsed.pathname + (parsed.search || ''),
      method  : options.method || 'GET',
      headers : options.headers || {},
      timeout : 10000,
    };

    const body = options.body ? JSON.stringify(options.body) : null;
    if (body) {
      reqOptions.headers['Content-Type']   = 'application/json';
      reqOptions.headers['Content-Length'] = Buffer.byteLength(body);
    }

    const req = lib.request(reqOptions, (res) => {
      let data = '';
      res.on('data', (chunk) => data += chunk);
      res.on('end', () => {
        try {
          resolve({ status: res.statusCode, body: JSON.parse(data) });
        } catch (e) {
          resolve({ status: res.statusCode, body: data });
        }
      });
    });

    req.on('error', reject);
    req.on('timeout', () => { req.destroy(); reject(new Error('request timeout')); });

    if (body) req.write(body);
    req.end();
  });
}

function cloudGet(path, params = {}) {
  const qs  = new URLSearchParams({ store_key: CONFIG.STORE_KEY, ...params }).toString();
  const url = `${CONFIG.CLOUD_BASE_URL}${path}?${qs}`;
  return request(url, {
    headers: { 'Authorization': `Bearer ${CONFIG.STORE_TOKEN}` }
  });
}

function cloudPost(path, body) {
  const url = `${CONFIG.CLOUD_BASE_URL}${path}?store_key=${encodeURIComponent(CONFIG.STORE_KEY)}`;
  return request(url, {
    method : 'POST',
    body,
    headers: { 'Authorization': `Bearer ${CONFIG.STORE_TOKEN}` }
  });
}

function localPost(path, body) {
  const url = `${CONFIG.LOCAL_BASE_URL}${path}`;
  return request(url, { method: 'POST', body });
}

// ---------------------------------------------------------------------------
// Job handlers — stub implementations; fill in real LOCAL_BASE_URL calls
// ---------------------------------------------------------------------------

/**
 * Handle PUSH_TO_STORE: create a new order in the local TGIF POS.
 *
 * @param  {object} job
 * @returns {Promise<{success, referenceId, error}>}
 */
async function handlePushToStore(job) {
  logger.info(`handlePushToStore up_order_id=${job.up_order_id} channel=${job.channel}`);

  try {
    // TODO: Map job.payload.items → local catalog_product ids using up_item_map
    //       then call the local TGIF order creation endpoint.
    const res = await localPost('/local_up/order_create', {
      up_order_id  : job.up_order_id,
      display_id   : job.up_order_display_id,
      channel      : job.channel,
      payload      : job.payload,
    });

    if (res.status === 200 && res.body && res.body.reference_id) {
      logger.info(`handlePushToStore OK reference_id=${res.body.reference_id}`);
      return { success: true, referenceId: res.body.reference_id };
    } else {
      const err = `local returned status=${res.status} body=${JSON.stringify(res.body)}`;
      logger.warn(`handlePushToStore FAIL ${err}`);
      return { success: false, error: err };
    }
  } catch (e) {
    logger.error(`handlePushToStore EXCEPTION ${e.message}`);
    return { success: false, error: e.message };
  }
}

/**
 * Handle UPDATE_STATUS: update an existing local order's status.
 */
async function handleUpdateStatus(job) {
  logger.info(`handleUpdateStatus up_order_id=${job.up_order_id}`);

  try {
    // TODO: look up local reference_id from local store DB or from job payload
    const res = await localPost('/local_up/order_update', {
      up_order_id: job.up_order_id,
      payload    : job.payload,
    });

    if (res.status === 200) {
      return { success: true };
    } else {
      return { success: false, error: `status=${res.status}` };
    }
  } catch (e) {
    logger.error(`handleUpdateStatus EXCEPTION ${e.message}`);
    return { success: false, error: e.message };
  }
}

/**
 * Handle CANCEL: cancel the local order.
 */
async function handleCancel(job) {
  logger.info(`handleCancel up_order_id=${job.up_order_id}`);

  try {
    const res = await localPost('/local_up/order_cancel', {
      up_order_id: job.up_order_id,
      payload    : job.payload,
    });

    if (res.status === 200) {
      return { success: true };
    } else {
      return { success: false, error: `status=${res.status}` };
    }
  } catch (e) {
    logger.error(`handleCancel EXCEPTION ${e.message}`);
    return { success: false, error: e.message };
  }
}

// ---------------------------------------------------------------------------
// Main poll loop
// ---------------------------------------------------------------------------

let lastEventId = 0;
let running     = false;

async function poll() {
  if (running) return; // skip if previous cycle still in progress
  running = true;

  try {
      
    // Pre-flight internet & cloud reachability check (fast parallel probe)
    const isOnline = await checkInternetConnection(2500);
    if (!isOnline) {
      logger.warn('No active internet connection or cloud unreachable. Pausing UrbanPiper polling...');
      wasOffline = true;
      nextDelay = OFFLINE_POLL_INTERVAL;
      return;
    }

    if (wasOffline) {
      logger.info('Internet / Cloud connection restored. Resuming UrbanPiper polling.');
      wasOffline = false;
    }

    // Heartbeat log every 15 polls (~30 seconds) so status is visible in logs
    if (pollCount % 15 === 0) {
      logger.info(`Heartbeat: UrbanPiper polling active (online, last_event_id=${lastEventId})`);
    }
    
    const res = await cloudGet('/urbanpiper/store/pull_jobs', { since_event_id: lastEventId });
	console.log(res); 
    if (res.status !== 200) {
      logger.warn(`pull_jobs failed status=${res.status}`);
      return;
    }
    const { jobs = [], last_event_id } = res.body;

	// console.log(jobs); return;
    if (jobs.length > 0) {
      logger.info(`poll received ${jobs.length} jobs since event_id=${lastEventId}`);
    }

    for (const job of jobs) {
      let result = { success: false, error: 'unknown_event_type' };

      switch (job.event_type) {
        case 'PUSH_TO_STORE':
          result = await handlePushToStore(job);
          break;
        case 'UPDATE_STATUS':
          result = await handleUpdateStatus(job);
          break;
        case 'CANCEL':
          result = await handleCancel(job);
          break;
        default:
          logger.warn(`unknown event_type=${job.event_type} event_id=${job.event_id}`);
          result = { success: true }; // ack unknowns so they don't block the queue
      }

      // Ack back to cloud
      try {
        const ackBody = {
          event_id    : job.event_id,
          up_order_id : job.up_order_id,
          success     : result.success,
          reference_id: result.referenceId || null,
          error       : result.error || null,
        };
        const ackRes = await cloudPost('/urbanpiper/store/ack_job', ackBody);
        if (ackRes.status === 200) {
          logger.info(`ack OK event_id=${job.event_id}`);
        } else {
          logger.warn(`ack FAIL event_id=${job.event_id} status=${ackRes.status}`);
        }
      } catch (ackErr) {
        logger.error(`ack EXCEPTION event_id=${job.event_id} ${ackErr.message}`);
      }
    }

    if (last_event_id && last_event_id > lastEventId) {
      lastEventId = last_event_id;
    }

  } catch (e) {
    logger.error(`poll EXCEPTION ${e.message}`);
  } finally {
    running = false;
  }
}

// ---------------------------------------------------------------------------
// Startup
// ---------------------------------------------------------------------------

logger.info('=== UrbanPiper Store Connector starting ===');
logger.info(`CLOUD_BASE_URL  = ${CONFIG.CLOUD_BASE_URL}`);
logger.info(`STORE_KEY       = ${CONFIG.STORE_KEY}`);
logger.info(`LOCAL_BASE_URL  = ${CONFIG.LOCAL_BASE_URL}`);
logger.info(`POLL_INTERVAL   = ${CONFIG.POLL_INTERVAL}ms`);
logger.info(`LOG_FILE        = ${CONFIG.LOG_FILE}`);

// Kick off immediately, then on interval
poll();
setInterval(poll, CONFIG.POLL_INTERVAL);

// Graceful shutdown
process.on('SIGTERM', () => { logger.info('SIGTERM received — shutting down'); process.exit(0); });
process.on('SIGINT',  () => { logger.info('SIGINT received — shutting down');  process.exit(0); });
