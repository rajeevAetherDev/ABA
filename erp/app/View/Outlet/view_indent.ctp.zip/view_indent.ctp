<?php
$indent = $indents[0]['inventory_indent'];
?>

<div class="row">
    <div class="col-sm-11">
        <div class="page-title-box">
            <h2 class="page-title">View Indent</h2>
        </div>
    </div>
    <div class="col-sm-1 text-right">
        <div class="page-title-box">
            <a href="indent"><button class="btn btn-danger" type="button">Back</button></a>
        </div>
    </div>
</div>

<div class="row mt-3">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <div class="form-group row">
                    <?php
                    $formInputs = [
                        ['label' => 'Indent ID', 'value' => $indent['indent_id']],
                        ['label' => 'Location Name', 'value' => $indent['location_name']],
                        ['label' => 'Expiry', 'value' => $indent['expiry'], 'condition' => !empty($indent['expiry'])],
                        ['label' => 'Total Amount', 'value' => number_format($indent['total_amount'], 2)],
                        ['label' => 'Approved Amount', 'value' => number_format($indent['approved_amount'], 2), 'condition' => !empty($indent['approved_amount'])],
                        ['label' => 'Processed Amount', 'value' => number_format($indent['processed_amount'], 2), 'condition' => !empty($indent['processed_amount'])],
                        ['label' => 'Remarks', 'value' => $indent['remarks'], 'condition' => !empty($indent['remarks'])],
                        ['label' => 'Vehicle Number', 'value' => $indent['vehicle_no'], 'condition' => !empty($indent['vehicle_no'])],
                    ];

                    foreach ($formInputs as $input) {
                        if (!isset($input['condition']) || $input['condition']) {
                            echo '<div class="col-sm-3 mb-2">';
                            echo $this->Form->input('', [
                                'label' => $input['label'],
                                'class' => 'form-control',
                                'readonly' => 'readonly',
                                'value' => $input['value'],
                            ]);
                            echo '</div>';
                        }
                    }
                    ?>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- Items Section -->
<div class="row mt-3">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <h4 class="page-title mb-3">Indent Items</h4>

                <?php foreach ($items as $item): 
                    $it = $item['inventory_indent_items'];
                    $status = $indent['status'];
                ?>
                    <div class="form-group row">
                        <?php
                        // Common fields
                        $fields = [
                            ['label' => 'Name', 'value' => $it['sku_name'], 'col' => ($status == 1 ? 3 : 2)],
                            ['label' => 'Unit', 'value' => $it['sku_unit_name'], 'col' => ($status == 1 ? 3 : ($status == 2 ? 2 : 1))],
                            ['label' => 'Price', 'value' => $it['sku_price'], 'col' => ($status == 1 ? 3 : ($status == 2 ? 2 : 1))],
                            ['label' => 'Quantity', 'value' => $it['sku_quantity'], 'col' => ($status == 1 ? 3 : ($status == 2 ? 2 : 1))],
                        ];

                        if ($status >= 2) {
                            $fields[] = ['label' => 'Approved Quantity', 'value' => $it['approved_quantity'], 'col' => 2];
                            $fields[] = ['label' => 'Approved Price', 'value' => $it['approved_price'], 'col' => 2];
                        }

                        if ($status == 3) {
                            $fields[] = ['label' => 'Processed Quantity', 'value' => $it['processed_quantity'], 'col' => 2];
                        }

                        // Render all fields
                        foreach ($fields as $f) {
                            echo '<div class="col-md-' . $f['col'] . ' mb-2">';
                            echo $this->Form->input('', [
                                'label' => $f['label'],
                                'div' => false,
                                'class' => 'form-control',
                                'readonly' => true,
                                'value' => $f['value']
                            ]);
                            echo '</div>';
                        }
                        ?>
                    </div>
                <?php endforeach; ?>
            </div>
        </div>
    </div>
</div>
