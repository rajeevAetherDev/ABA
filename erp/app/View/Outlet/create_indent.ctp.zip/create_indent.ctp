<div class="row">
    <div class="col-sm-10">
        <div class="page-title-box">
            <h2 class="page-title">Create Indent</h2>
        </div>
    </div>
    <div class="col-sm-2">
        <div class="page-title-box">
            <h2 class="page-title">
                <a href="indent">
                    <button class='btn btn-danger' type="button" style="float:right">Back</button>
                </a>
            </h2>
        </div>
    </div>
</div>

<div class="row">
    <div class="col-sm-12">
        <div class="card">
            <div class="card-body">
                <?php
                echo $this->Form->create(false, ['id' => 'internalIndentForm']);

                echo $this->Form->input('location', [
                    'label' => 'Location',
                    'class' => 'form-control',
                    'value' => $locations,
                    'id' => 'location',
                    'type' => 'hidden'
                ]);

                $options = ['' => 'Select Warehouse'];
                foreach ($optlocations as $location) {
                    $options[$location['Location']['id']] = h($location['Location']['name']);
                }

                echo $this->Form->input('dclocation', [
                    'div' => ['class' => 'form-group'],
                    'label' => 'Select Warehouse',
                    'class' => 'form-control',
                    'options' => $options,
                    'id' => 'dclocation',
                    'required' => true
                ]);

                echo $this->Form->input('expiry', [
                    'label' => 'Expiry Date',
                    'type' => 'text',
                    'class' => 'form-control',
                    'id' => 'expiry',
                    'value' => date('Y-m-d'),
                    'after' => '<script>document.getElementById("expiry").type = "date";</script>'
                ]);
                ?>

                <br>
                <table id="example" class="display table table-hover table-condensed" cellspacing="0" width="100%">
                    <thead>
                        <tr>
                            <th>#</th>
                            <th>Type</th>
                            <th>Name</th>
                            <th>Category</th>
                            <th>Unit Name</th>
                            <th>Price</th>
                            <th>Available Quantity</th>
                            <th>Quantity</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $x = 1;
                        foreach ($items as $item):
                            if (isset($item['Inventory_semifinished'])) {
                                $sku = $item['Inventory_semifinished'];
                                $type = 'Semifinished';
                            } else {
                                $sku = $item['Inventory_sku'];
                                $type = 'SKU';
                            }
                        ?>
                            <tr>
                                <td><?= $x; ?></td>
                                <td><?= $type; ?></td>
                                <td><?= h($sku['name']); ?></td>
                                <td><?= h($sku['cat_name'] ?? '-'); ?></td>
                                <td><?= h($sku['unit_name'] ?? '-'); ?></td>
                                <td><?= h($sku['price'] ?? '0'); ?></td>
                                <td><?= h($sku['actual_balance'] ?? 'NA'); ?></td>
                                <td>
                                    <?= $this->Form->input("quantity[{$type}_{$sku['id']}]", [
                                        'class' => 'form-control',
                                        'label' => false,
                                        'type' => 'number',
                                        'style' => 'width:auto',
                                        'value' => 0,
                                        'min' => 0,
                                        'id' => 'quantity_' . $type . '_' . $sku['id']
                                    ]); ?>
                                </td>

                                <input type="hidden" name="sku_id[<?= $type . '_' . $sku['id']; ?>]" value="<?= $sku['id']; ?>">
                                <input type="hidden" name="sku_name[<?= $type . '_' . $sku['id']; ?>]" id="sku_name_<?= $type . '_' . $sku['id']; ?>" value="<?= h($sku['name']); ?>">
                                <input type="hidden" name="sku_price[<?= $type . '_' . $sku['id']; ?>]" id="sku_price_<?= $type . '_' . $sku['id']; ?>" value="<?= h($sku['price']); ?>">
                                <input type="hidden" name="unit_name[<?= $type . '_' . $sku['id']; ?>]" id="unit_name_<?= $type . '_' . $sku['id']; ?>" value="<?= h($sku['unit_name']); ?>">
                                <input type="hidden" name="unit_id[<?= $type . '_' . $sku['id']; ?>]" id="unit_id_<?= $type . '_' . $sku['id']; ?>" value="<?= h($sku['unit']); ?>">
                                <input type="hidden" name="item_type[<?= $type . '_' . $sku['id']; ?>]" id="item_type_<?= $type . '_' . $sku['id']; ?>" value="<?= $type; ?>">
                            </tr>
                        <?php $x++; endforeach; ?>
                    </tbody>
                </table><br>

                <div class="row">
                    <div class="col-md-12">
                        <button type="button" onclick="getCheckedCheckboxes()" class="btn btn-success" style="float:right;">Save</button>
                        <a href="indent">
                            <button class='btn btn-danger' type="button" style="float:right; margin-right: 10px;">Cancel</button>
                        </a>
                    </div>
                </div>
                <?= $this->Form->end(); ?>
            </div>
        </div>
    </div>
</div>

<script>
function getCheckedCheckboxes() {
    const locationId = $('#location').val();
    const expiry = $('#expiry').val();
    const dclocation = $('#dclocation').val();

    if (!dclocation) {
        Swal.fire({
            icon: 'warning',
            text: 'Please select Warehouse.',
            confirmButtonColor: '#d33',
        });
        return;
    }
    if (!expiry) {
        Swal.fire({
            icon: 'warning',
            text: 'Please select expiry date.',
            confirmButtonColor: '#d33',
        });
        return;
    }

    const checkedData = [];

    $("input[type='number'][id^='quantity_']").each(function () {
        const quantity = $(this).val().trim();
        const itemKey = this.id.replace('quantity_', '');

        if (quantity !== "" && quantity !== "0") {
            checkedData.push({
                id: itemKey,
                sku_name: $('#sku_name_' + itemKey).val(),
                unit_name: $('#unit_name_' + itemKey).val(),
                unit_id: $('#unit_id_' + itemKey).val(),
                sku_quantity: quantity,
                price: $('#sku_price_' + itemKey).val(),
                item_type: $('#item_type_' + itemKey).val()
            });
        }
    });

    if (checkedData.length === 0) {
        Swal.fire({
            icon: 'warning',
            title: 'No items selected',
            text: 'Please enter quantity for at least one item.',
            confirmButtonColor: '#d33',
        });
        return;
    }

    $.ajax({
        url: '<?= $this->Html->url(['controller' => 'outlet', 'action' => 'add_indent']); ?>',
        type: 'POST',
        data: {
            location_id: locationId,
            dclocation: dclocation,
            expiry: expiry,
            checkedData: JSON.stringify(checkedData)
        },
        success: function (response) {
            Swal.fire({
                icon: 'success',
                title: 'Saved successfully!',
                showConfirmButton: false,
                timer: 1200
            }).then(() => {
                window.location.href = 'indent';
            });
        },
        error: function (xhr, status, error) {
            Swal.fire({
                icon: 'error',
                title: 'An error occurred',
                text: error,
                confirmButtonColor: '#d33',
            });
        }
    });
}
</script>
